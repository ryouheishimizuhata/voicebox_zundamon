import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton, QSlider, QListWidget, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from PyQt5.QtMultimedia import QSoundEffect
from playsound import playsound
import pyttsx3

# データ読み込み
data = pd.read_csv('path_to_csv_file')  # CSVファイルのパスを指定してください

# WAVファイルのパス
w1 = 'path_to_wav_file'  # タスク選択の音声ファイル
w2 = 'path_to_wav_file'  # 目的変数選択の音声ファイル
w3 = 'path_to_wav_file'  # 説明変数選択の音声ファイル
w4 = 'path_to_wav_file'  # テストデータ割合選択の音声ファイル
w5 = 'path_to_wav_file'  # 分析実行の音声ファイル
w6 = 'path_to_wav_file'  # 分析終了の音声ファイル

class MLTaskPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("機械学習タスク選択")

        self.ml_task_label = QLabel("機械学習タスクを選択してください：", self)
        self.ml_task_combobox = QComboBox(self)
        self.ml_task_combobox.addItem("回帰")
        self.ml_task_combobox.addItem("分類")

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.ml_task_label)
        self.layout.addWidget(self.ml_task_combobox)
        self.layout.addWidget(self.next_button)

    def go_to_next_page(self):
        ml_task = self.ml_task_combobox.currentText()

        target_page = TargetVariablePage(ml_task)
        self.parent().setCentralWidget(target_page)

class TargetVariablePage(QWidget):
    def __init__(self, ml_task, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("目的変数選択")

        self.ml_task = ml_task
        self.target_label = QLabel("目的変数を選択してください：", self)
        self.target_combobox = QComboBox(self)
        self.target_combobox.addItems(data.columns)

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.target_label)
        self.layout.addWidget(self.target_combobox)
        self.layout.addWidget(self.next_button)

    def go_to_next_page(self):
        target_variable = self.target_combobox.currentText()

        if self.ml_task == "回帰":
            feature_page = FeatureSelectionPage(target_variable)
            self.parent().setCentralWidget(feature_page)
        elif self.ml_task == "分類":
            test_ratio_page = TestRatioPage(target_variable)
            self.parent().setCentralWidget(test_ratio_page)

class FeatureSelectionPage(QWidget):
    def __init__(self, target_variable, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("説明変数選択")

        self.target_variable = target_variable
        self.feature_label = QLabel("説明変数を選択してください：", self)
        self.feature_list = QListWidget(self)
        self.feature_list.addItems(data.columns)
        self.feature_list.setSelectionMode(QListWidget.MultiSelection)

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.feature_label)
        self.layout.addWidget(self.feature_list)
        self.layout.addWidget(self.next_button)

    def go_to_next_page(self):
        selected_features = [item.text() for item in self.feature_list.selectedItems()]

        test_ratio_page = TestRatioPage(self.target_variable, selected_features)
        self.parent().setCentralWidget(test_ratio_page)

class TestRatioPage(QWidget):
    def __init__(self, target_variable, selected_features=None, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("テストデータ割合選択")

        self.target_variable = target_variable
        self.selected_features = selected_features

        self.ratio_label = QLabel("テストデータの割合を選択してください：", self)
        self.ratio_slider = QSlider(Qt.Horizontal, self)
        self.ratio_slider.setRange(0, 100)
        self.ratio_slider.setSingleStep(10)
        self.ratio_slider.setTickInterval(10)
        self.ratio_slider.setValue(20)
        self.ratio_slider.setTickPosition(QSlider.TicksBelow)

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.execute_analysis)

        self.layout.addWidget(self.ratio_label)
        self.layout.addWidget(self.ratio_slider)
        self.layout.addWidget(self.next_button)

    def execute_analysis(self):
        test_ratio = self.ratio_slider.value() / 100.0

        if self.selected_features:
            X = data[self.selected_features]
        else:
            X = data.drop(columns=[self.target_variable])
        y = data[self.target_variable]

        if isinstance(y.iloc[0], (int, float)):
            if len(y.unique()) > 10:
                QMessageBox.warning(self, "警告", "目的変数の種類が多すぎます。分類タスクを選択してください。")
                return
            model = LinearRegression()
        else:
            model = RandomForestClassifier()

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_ratio, random_state=0)

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        if isinstance(y.iloc[0], (int, float)):
            # 回帰タスクの場合の処理
            # ここに回帰タスクの結果表示などの処理を追加する
            pass
        else:
            # 分類タスクの場合の処理
            # ここに分類タスクの結果表示などの処理を追加する
            pass

        QMessageBox.information(self, "情報", "分析が終了しました。")

        # 分析終了後の処理を実行
        self.execute_finished()

    def execute_finished(self):
        # 分析終了後の処理を実装
        # ここに音声ファイル再生などの処理を追加する
        playsound(w6)
        # または、テキスト読み上げを行う場合は以下のコードを使用
        # engine = pyttsx3.init()
        # engine.say("分析が終了しました。")
        # engine.runAndWait()
        # または、別の処理に移るための関数を呼び出すなどの処理を追加する

app = QApplication(sys.argv)

main_window = QMainWindow()
ml_task_page = MLTaskPage()
main_window.setCentralWidget(ml_task_page)
main_window.show()

sys.exit(app.exec_())

