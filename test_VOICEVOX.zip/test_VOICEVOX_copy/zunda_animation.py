from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QLabel, QApplication

animation_images = [
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0000.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0002.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",]
    # ここにアニメーションの全ての画像ファイルを列挙します

class AnimationWindow(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.animation_index = 0
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animation)

    def start_animation(self):
        self.animation_index = 0
        self.animation_timer.start(500)  # 100ミリ秒ごとに画像を切り替える

    def stop_animation(self):
        self.animation_timer.stop()

    def update_animation(self):
        image_path = animation_images[self.animation_index]
        pixmap = QPixmap(image_path)
        self.setPixmap(pixmap)

        self.animation_index += 1
        if self.animation_index >= len(animation_images):
            self.animation_index = 0

if __name__ == "__main__":
    app = QApplication([])
    window = AnimationWindow()
    window.start_animation()
    window.show()
    app.exec_()
