import sys
import requests
import json
import wave
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

# APIエンドポイント
audio_query_endpoint = f"http://localhost:50021/audio_query"
synthesis_endpoint = f"http://localhost:50021/synthesis"

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VOICEVOXアプリケーション")
        self.speaker= 1

        # テキスト入力フィールドの作成
        self.text_input = QLineEdit(self)

        # ラベルの作成
        self.label = QLabel("テキストを入力してください:", self)

        # 音声生成ボタンの作成
        self.generate_button = QPushButton("音声生成", self)
        self.generate_button.clicked.connect(self.generate_voice)

        # レイアウトの作成
        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.text_input)
        layout.addWidget(self.generate_button)

        # セントラルウィジェットの作成
        central_widget = QWidget(self)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

    def generate_voice(self):
        text = self.text_input.text()
        print(text)
        # クエリを作成するAPIエンドポイントに対してPOSTリクエストを送信
        query_response = requests.post(audio_query_endpoint, params=(("text",text),("speaker",self.speaker)))

        if query_response.status_code == 200:
            # 音声を合成するAPIエンドポイントに対してPOSTリクエストを送信
            headers = {'Content-Type': 'application/json',}
            synthesis_response = requests.post(synthesis_endpoint, params={"speaker":self.speaker},headers=headers,data=json.dumps(query_response.json()))

            if synthesis_response.status_code == 200:
                voice_data = synthesis_response.content
                print("Success!")

                # 音声データを保存する例
                # ファイル名をテキストと同じにする
                filepath = f"./{text}.wav"
                with open(filepath, "wb") as f:
                          f.write(voice_data)
               

        else:
            print("Failed to create query.")
            print(query_response.status_code)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

# # 正常に動作する

# import json
# import requests
# import wave

# def generate_wav(text, speaker=1, filepath='./audio.wav'):
#     host = 'localhost'
#     port = 50021
#     params = (
#         ('text', text),
#         ('speaker', speaker),
#     )
#     response1 = requests.post(
#         f'http://{host}:{port}/audio_query',
#         params=params
#     )
#     headers = {'Content-Type': 'application/json',}
#     response2 = requests.post(
#         f'http://{host}:{port}/synthesis',
#         headers=headers,
#         params=params,
#         data=json.dumps(response1.json())
#     )

#     wf = wave.open(filepath, 'wb')
#     wf.setnchannels(1)
#     wf.setsampwidth(2)
#     wf.setframerate(24000)
#     wf.writeframes(response2.content)
#     wf.close()
    
#     print(text)
# if __name__ == '__main__':
#     text = 'こんにちは！'
#     generate_wav(text)







