# import modules
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QSlider, QPushButton, QListWidget, QTabWidget
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QSizePolicy
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor
from PyQt5.QtWidgets import QFileDialog
import matplotlib.pyplot as plt
import pyttsx3
from playsound import playsound
# QMessageBox
from PyQt5.QtWidgets import QMessageBox

# # CSVデータの読み込みとデータ操作
# data = pd.read_csv(r"C:\Users\amesh\Desktop\test_VOICEVOX\odor_data_3.csv").fillna(0)


# ずんだもんのアニメーション画像のパス
animation_images = [
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0002.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0000.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",]

animation_images_2 = [
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0004.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0005.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",
    r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_image\ずんだもん立ち絵素材2_0001.png",]
    # ここにアニメーションの全ての画像ファイルを列挙します

# WAVファイルのパス（音声）
w0 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\please_write_path.wav"
w1 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\start_with_zunda.wav"
w2 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\which_kaiseki.wav"
w3 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\which_is_target.wav"
w4 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\which_are_features.wav"
w4_5 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\select_test_ratio.wav"
w5 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\start_learning.wav"
w6 = r"C:\Users\amesh\Desktop\test_VOICEVOX\zundamon_sound\end.wav"

# mainwindow
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ずんだもんと分析しよう！")  # ウィンドウのタイトルを設定
        playsound(w1)
    def load_data(self, file_path):
        global data
        data = pd.read_csv(file_path)
        ml_task_page = MLTaskPage()
        self.setCentralWidget(ml_task_page)

# ずんだもんのアニメーション画像を表示するためのクラス
class AnimationWindow(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.animation_index = 0
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animation)

    def start_animation(self):
        self.animation_index = 0
        self.animation_timer.start(400)  # 100ミリ秒ごとに画像を切り替える

    def stop_animation(self):
        self.animation_timer.stop()

    def update_animation(self):
        image_path = animation_images[self.animation_index]
        pixmap = QPixmap(image_path)
        self.setPixmap(pixmap)

        self.animation_index += 1
        if self.animation_index >= len(animation_images):
            self.animation_index = 0

class AnimationWindow_2(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.animation_index = 0
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animation)

    def start_animation(self):
        self.animation_index = 0
        self.animation_timer.start(50)  # 100ミリ秒ごとに画像を切り替える

    def stop_animation(self):
        self.animation_timer.stop()

    def update_animation(self):
        image_path = animation_images_2[self.animation_index]
        pixmap = QPixmap(image_path)
        self.setPixmap(pixmap)

        self.animation_index += 1
        if self.animation_index >= len(animation_images):
            self.animation_index = 0

class DataPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        playsound(w0)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("データの選択")
        self.ml_task_label = QLabel("使用するデータのディレクトリを指定してください：", self)

        self.button_layout = QHBoxLayout()
        button = QPushButton("Open File", self)
        button.clicked.connect(self.openFileDialog)
        self.button_layout.addWidget(button)

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.animation)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.ml_task_label)
        self.layout.addLayout(self.button_layout)
        self.layout.addWidget(self.next_button)

        animation_window = AnimationWindow()
        self.layout.addWidget(animation_window)
        # アニメーションを開始
        animation_window.start_animation()

    def openFileDialog(self):
        options = QFileDialog.Options()
        options |= QFileDialog.ReadOnly  # 読み取り専用モード
        fileName, _ = QFileDialog.getOpenFileName(self, "Open File", "", "CSV Files (*.csv);;All Files (*)", options=options)
        self.fileName = fileName
        if fileName:
            print("Selected File:", fileName)
    
    def animation(self):
        # アニメーションを停止
        animation_window = AnimationWindow_2()
        self.layout.addWidget(animation_window)
        # アニメーションを開始
        animation_window.start_animation()

    # ml_task_comboboxの値を取得して、次のページに遷移する
    def go_to_next_page(self):
        data = pd.read_csv(self.fileName)
        print(data)
        target_page = MLTaskPage(data)
        self.parent().setCentralWidget(target_page)

class MLTaskPage(QWidget):
    def __init__(self,data, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.data = data
        self.setWindowTitle("機械学習タスク選択")

        self.ml_task_label = QLabel("機械学習タスクを選択してください：", self)
        self.ml_task_combobox = QComboBox(self)
        self.ml_task_combobox.addItem("回帰")
        self.ml_task_combobox.addItem("分類")

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.ml_task_label)
        self.layout.addWidget(self.ml_task_combobox)
        self.layout.addWidget(self.next_button)

        animation_window = AnimationWindow()
        self.layout.addWidget(animation_window)
        # アニメーションを開始
        animation_window.start_animation()
        playsound(w2)
    
    # ml_task_comboboxの値を取得して、次のページに遷移する
    def go_to_next_page(self):
        animation_window_2 = AnimationWindow_2()
        self.layout.addWidget(animation_window_2)
        animation_window_2.start_animation()
        data = self.data
        ml_task = self.ml_task_combobox.currentText()
        target_page = TargetVariablePage(data,ml_task)
        self.parent().setCentralWidget(target_page)

class TargetVariablePage(QWidget):
    def __init__(self,data, ml_task, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("目的変数選択")

        self.data = data
        self.ml_task = ml_task
        self.target_label = QLabel("目的変数を選択してください：", self)
        self.target_combobox = QComboBox(self)
        self.target_combobox.addItems(data.columns)

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.target_label)
        self.layout.addWidget(self.target_combobox)
        self.layout.addWidget(self.next_button)

        animation_window = AnimationWindow()
        self.layout.addWidget(animation_window)
        # アニメーションを開始
        animation_window.start_animation()
        playsound(w3)

    # 情報を継承して次のページに遷移する
    def go_to_next_page(self):
        animation_window_2 = AnimationWindow_2()
        self.layout.addWidget(animation_window_2)
        animation_window_2.start_animation()
        target_variable = self.target_combobox.currentText()
        data = self.data
        ml_task = self.ml_task
        feature_page = FeatureSelectionPage(target_variable,ml_task,data)
        self.parent().setCentralWidget(feature_page)

# 特徴量選択部分のページ
class FeatureSelectionPage(QWidget):
    def __init__(self, target_variable, ml_task ,data,parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.data = data
        self.ml_task = ml_task
        self.setLayout(self.layout)
        self.setWindowTitle("説明変数選択")

        self.target_variable = target_variable
        self.feature_label = QLabel("説明変数を選択してください：", self)
        self.feature_list = QListWidget(self)
        self.feature_list.addItems(data.columns)
        self.feature_list.setSelectionMode(QListWidget.MultiSelection)

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.go_to_next_page)

        self.layout.addWidget(self.feature_label)
        self.layout.addWidget(self.feature_list)
        self.layout.addWidget(self.next_button)

        animation_window = AnimationWindow()
        self.layout.addWidget(animation_window)
        # アニメーションを開始
        animation_window.start_animation()

        playsound(w4)

    def go_to_next_page(self):
        animation_window_2 = AnimationWindow_2()
        self.layout.addWidget(animation_window_2)
        animation_window_2.start_animation()
        selected_features = [item.text() for item in self.feature_list.selectedItems()]
        data = self.data
        ml_task = self.ml_task
        test_ratio_page = TestRatioPage(self.target_variable, selected_features,ml_task,data)
        self.parent().setCentralWidget(test_ratio_page)

# テストデータ割合選択部分のページ
class TestRatioPage(QWidget):
    def __init__(self, target_variable,selected_features, ml_task,data, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.setWindowTitle("テストデータ割合選択")
        
        self.data = data
        self.ml_task = ml_task
        self.target_variable = target_variable
        self.selected_features = selected_features

        self.ratio_label = QLabel("テストデータの割合を選択してください：", self)
        self.ratio_slider = QSlider(Qt.Horizontal, self)
        self.ratio_slider.setRange(0, 100)
        self.ratio_slider.setSingleStep(10)
        self.ratio_slider.setTickInterval(10)
        self.ratio_slider.setValue(20)
        self.ratio_slider.setTickPosition(QSlider.TicksBelow)

        self.ratio_value_label = QLabel(f"{self.ratio_slider.value()}%", self)  # スライダーの値を表示するラベル

        self.next_button = QPushButton("次へ", self)
        self.next_button.clicked.connect(self.execute_analysis)

        self.layout.addWidget(self.ratio_label)
        self.layout.addWidget(self.ratio_slider)
        self.layout.addWidget(self.ratio_value_label)
        self.layout.addWidget(self.next_button)

        self.ratio_slider.valueChanged.connect(self.update_ratio_value)

        animation_window = AnimationWindow()
        self.layout.addWidget(animation_window)
        # アニメーションを開始
        animation_window.start_animation()
        playsound(w4_5)

    def update_ratio_value(self, value):
        self.ratio_value_label.setText(f"{value}%")        
   
    # 入力内容を元に分析を実行する
    def execute_analysis(self):
        data = self.data
        # テストデータの割合を取得
        test_ratio = self.ratio_slider.value() / 100.0
        # 選択した説明変数を取得
        if self.selected_features:
            X = data[self.selected_features]
        else:
            X = data.drop(columns=[self.target_variable])
        # 目的変数を取得
        y = data[self.target_variable]
        # 目的変数の種類によってモデルを変更
        # TargetVariablePageのself.ml_task == "回帰"であれば回帰モデルを、そうでなければ分類モデルを選択
        if self.ml_task == "回帰":
            playsound(w5)
            model = RandomForestRegressor(random_state=0)
        elif self.ml_task == "分類":
            if len(y.unique()) > 10:
                QMessageBox.warning(self, "警告", "目的変数の種類が多すぎます。回帰タスクを選択してください。")
                return
            playsound(w5)
            model = RandomForestClassifier(random_state=0)
        
        # 目的変数の種類によって処理を変更
        # 回帰タスクの場合
        if self.ml_task == "回帰":
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_ratio,random_state=0)
            # モデルを学習
            model.fit(X_train, y_train)
            # テストデータで予測
            y_pred = model.predict(X_test)
            #　RMSEを計算
            rmse = np.sqrt(mean_squared_error(y_test, y_pred))
            # R^2を計算
            r2 = r2_score(y_test, y_pred)  
            # 結果をプロット
            plt.scatter(y_test, y_pred)
            plt.xlabel("Actual")
            plt.ylabel("Predicted")
            plt.title(f"RMSE: {rmse:.2f},R^2: {r2:.2f}")
            # x=yの直線をプロット
            plt.plot([y.min(), y.max()], [y.min(), y.max()], "k--")
            plt.show()
            # 回帰タスクの場合の処理
            pass
        elif self.ml_task == "分類":
            # データを学習用とテスト用に分割
            X_train, X_test, y_train, y_test = train_test_split(X, y,test_size=test_ratio,stratify=y ,random_state=0)
            # モデルを学習
            model.fit(X_train, y_train)
            # テストデータで予測
            y_pred = model.predict(X_test)
            # classification_reportを表示
            print(classification_report(y_test, y_pred))
            if len(y_train.unique()) == 2:
            # ROC曲線をプロット
                fpr, tpr, thresholds = roc_curve(y_test, y_pred)
                plt.plot(fpr, tpr, label="ROC Curve")
                plt.xlabel("FPR")
                plt.ylabel("TPR (recall)")
                # 直線x=yをプロット
                plt.plot([0, 1], [0, 1], "k--")
                plt.show()
                # ここに分類タスクの結果表示などの処理を追加する
            pass

        QMessageBox.information(self, "情報", "分析が終了しました。")

        # 分析終了後の処理を実行
        self.execute_finished()

    def execute_finished(self):
        # 分析終了後の処理を実装
        # ここに音声ファイル再生などの処理を追加する   
        # または、テキスト読み上げを行う場合は以下のコードを使用
        engine = pyttsx3.init()
        animation_window_2 = AnimationWindow_2()
        self.layout.addWidget(animation_window_2)
        animation_window_2.start_animation()
        playsound(w6)
        # engine.say("分析が終了しました。")
        # engine.runAndWait()
        # または、別の処理に移るための関数を呼び出すなどの処理を追加する

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    ml_task_page = DataPage()
    main_window.setCentralWidget(ml_task_page)
    main_window.show()

    sys.exit(app.exec_())




